<?php
$module_name = 'cstm_TestMessages';
$listViewDefs [$module_name] = 
array (
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => true,
  ),
  'MESSAGE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MESSAGE',
    'width' => '10%',
    'default' => true,
  ),
);
;
?>
