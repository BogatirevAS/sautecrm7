<?php
$dashletData['cstm_TestMessagesDashlet']['searchFields'] = array (
  'date_entered' => 
  array (
    'default' => '',
  ),
  'message' => 
  array (
    'default' => '',
  ),
);
$dashletData['cstm_TestMessagesDashlet']['columns'] = array (
  'date_entered' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => true,
    'name' => 'date_entered',
  ),
  'message' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MESSAGE',
    'width' => '10%',
    'default' => true,
    'name' => 'message',
  ),
);
